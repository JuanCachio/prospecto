﻿
namespace Examen
{
    partial class Observacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtobserva = new System.Windows.Forms.TextBox();
            this.txtiddd = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtobserva
            // 
            this.txtobserva.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtobserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtobserva.Location = new System.Drawing.Point(0, 0);
            this.txtobserva.Multiline = true;
            this.txtobserva.Name = "txtobserva";
            this.txtobserva.ReadOnly = true;
            this.txtobserva.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txtobserva.Size = new System.Drawing.Size(248, 117);
            this.txtobserva.TabIndex = 0;
            // 
            // txtiddd
            // 
            this.txtiddd.Location = new System.Drawing.Point(109, 2);
            this.txtiddd.Name = "txtiddd";
            this.txtiddd.ReadOnly = true;
            this.txtiddd.Size = new System.Drawing.Size(10, 20);
            this.txtiddd.TabIndex = 1;
            this.txtiddd.Visible = false;
            // 
            // Observacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(248, 117);
            this.Controls.Add(this.txtobserva);
            this.Controls.Add(this.txtiddd);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Observacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Observacion";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Observacion_FormClosing);
            this.Load += new System.EventHandler(this.Observacion_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox txtobserva;
        public System.Windows.Forms.TextBox txtiddd;
    }
}