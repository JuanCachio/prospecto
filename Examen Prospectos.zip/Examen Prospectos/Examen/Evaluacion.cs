﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Diagnostics;

namespace Examen
{
    public partial class Evaluacion : Form
    {
        public Evaluacion()
        {
            InitializeComponent();
        }

        private void btnvolver_Click(object sender, EventArgs e)
        {
            this.Hide();
            Listado_de_Prospectos f1 = new Listado_de_Prospectos();
            f1.Show();
        }
        public DataTable llenar_grid()
        {
            Conexion.Conectar();
            DataTable dt = new DataTable();
            string consulta = "SELECT NOMBRE, APELLIDO, SEGUNDOAPELLIDO, CALLE, NUMERO, COLONIA, CODIGOPOSTAL, TELEFONO, RFC, ESTATUS, OBSERVACIONES, nombrereal FROM prospectos order by id asc";
            SqlCommand cmd = new SqlCommand(consulta, Conexion.Conectar());

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            return dt;

        }
        private void button2_Click(object sender, EventArgs e)
        {
            Conexion.Conectar();
            string act = "UPDATE prospectos SET ESTATUS=@es, OBSERVACIONES=@ob WHERE id=@id";
            SqlCommand cmd3 = new SqlCommand(act, Conexion.Conectar());
            cmd3.Parameters.AddWithValue("@id", txtidd.Text);
            cmd3.Parameters.AddWithValue("@es", cmbestatus.Text);
            cmd3.Parameters.AddWithValue("@ob", txt10.Text);
            cmd3.ExecuteNonQuery();

            MessageBox.Show("Su evaluación a sido guardada");
            Listado_de_Prospectos lp = new Listado_de_Prospectos();
            lp.Show();
            this.Hide();
        }
    }
}
