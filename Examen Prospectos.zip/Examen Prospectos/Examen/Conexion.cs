﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Examen
{
    class Conexion
    {
        public static SqlConnection Conectar()
        {
            SqlConnection cn = new SqlConnection("SERVER=DESKTOP-2A1QJAA;DATABASE=bdexamen;integrated security=true");
            cn.Open();
            return cn;
        }
    }
}
