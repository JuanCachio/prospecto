﻿namespace Examen
{
    partial class Evaluacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt10 = new System.Windows.Forms.TextBox();
            this.btnvolver = new System.Windows.Forms.Button();
            this.lblobserv = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txt7 = new System.Windows.Forms.TextBox();
            this.txt6 = new System.Windows.Forms.TextBox();
            this.txt5 = new System.Windows.Forms.TextBox();
            this.txt4 = new System.Windows.Forms.TextBox();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblestatus = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txt8 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt9 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbestatus = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.txtidd = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txt10
            // 
            this.txt10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.txt10.Location = new System.Drawing.Point(167, 298);
            this.txt10.MaxLength = 99999;
            this.txt10.Multiline = true;
            this.txt10.Name = "txt10";
            this.txt10.Size = new System.Drawing.Size(192, 63);
            this.txt10.TabIndex = 2;
            // 
            // btnvolver
            // 
            this.btnvolver.BackColor = System.Drawing.Color.LightCoral;
            this.btnvolver.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnvolver.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnvolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvolver.Location = new System.Drawing.Point(185, 370);
            this.btnvolver.Name = "btnvolver";
            this.btnvolver.Size = new System.Drawing.Size(87, 35);
            this.btnvolver.TabIndex = 4;
            this.btnvolver.Text = "Regresar";
            this.btnvolver.UseVisualStyleBackColor = false;
            this.btnvolver.Click += new System.EventHandler(this.btnvolver_Click);
            // 
            // lblobserv
            // 
            this.lblobserv.AutoSize = true;
            this.lblobserv.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblobserv.Location = new System.Drawing.Point(66, 301);
            this.lblobserv.Name = "lblobserv";
            this.lblobserv.Size = new System.Drawing.Size(95, 13);
            this.lblobserv.TabIndex = 5;
            this.lblobserv.Text = "Observaciones:";
            // 
            // txt1
            // 
            this.txt1.BackColor = System.Drawing.Color.White;
            this.txt1.Enabled = false;
            this.txt1.Location = new System.Drawing.Point(167, 42);
            this.txt1.MaxLength = 20;
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(192, 20);
            this.txt1.TabIndex = 61;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(7, 43);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(154, 15);
            this.label10.TabIndex = 76;
            this.label10.Text = "Nombre del Prospecto:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(61, 199);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 15);
            this.label8.TabIndex = 74;
            this.label8.Text = "Código Postal:";
            // 
            // txt7
            // 
            this.txt7.BackColor = System.Drawing.Color.White;
            this.txt7.Enabled = false;
            this.txt7.Location = new System.Drawing.Point(167, 198);
            this.txt7.MaxLength = 50;
            this.txt7.Name = "txt7";
            this.txt7.ReadOnly = true;
            this.txt7.Size = new System.Drawing.Size(192, 20);
            this.txt7.TabIndex = 67;
            // 
            // txt6
            // 
            this.txt6.BackColor = System.Drawing.Color.White;
            this.txt6.Enabled = false;
            this.txt6.Location = new System.Drawing.Point(167, 172);
            this.txt6.MaxLength = 50;
            this.txt6.Name = "txt6";
            this.txt6.ReadOnly = true;
            this.txt6.Size = new System.Drawing.Size(192, 20);
            this.txt6.TabIndex = 66;
            // 
            // txt5
            // 
            this.txt5.BackColor = System.Drawing.Color.White;
            this.txt5.Enabled = false;
            this.txt5.Location = new System.Drawing.Point(167, 146);
            this.txt5.MaxLength = 11;
            this.txt5.Name = "txt5";
            this.txt5.ReadOnly = true;
            this.txt5.Size = new System.Drawing.Size(192, 20);
            this.txt5.TabIndex = 65;
            // 
            // txt4
            // 
            this.txt4.BackColor = System.Drawing.Color.White;
            this.txt4.Enabled = false;
            this.txt4.Location = new System.Drawing.Point(167, 120);
            this.txt4.MaxLength = 45;
            this.txt4.Name = "txt4";
            this.txt4.ReadOnly = true;
            this.txt4.Size = new System.Drawing.Size(192, 20);
            this.txt4.TabIndex = 64;
            // 
            // txt3
            // 
            this.txt3.BackColor = System.Drawing.Color.White;
            this.txt3.Enabled = false;
            this.txt3.Location = new System.Drawing.Point(167, 94);
            this.txt3.MaxLength = 15;
            this.txt3.Name = "txt3";
            this.txt3.ReadOnly = true;
            this.txt3.Size = new System.Drawing.Size(192, 20);
            this.txt3.TabIndex = 63;
            // 
            // txt2
            // 
            this.txt2.BackColor = System.Drawing.Color.White;
            this.txt2.Enabled = false;
            this.txt2.Location = new System.Drawing.Point(167, 68);
            this.txt2.MaxLength = 40;
            this.txt2.Name = "txt2";
            this.txt2.ReadOnly = true;
            this.txt2.Size = new System.Drawing.Size(192, 20);
            this.txt2.TabIndex = 62;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(99, 147);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 15);
            this.label6.TabIndex = 73;
            this.label6.Text = "Número:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(117, 121);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 15);
            this.label5.TabIndex = 72;
            this.label5.Text = "Calle:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(37, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(124, 15);
            this.label4.TabIndex = 71;
            this.label4.Text = "Segundo Apellido:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(51, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 15);
            this.label3.TabIndex = 70;
            this.label3.Text = "Primer Apellido:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(101, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 15);
            this.label2.TabIndex = 69;
            this.label2.Text = "Colonia:";
            // 
            // lblestatus
            // 
            this.lblestatus.AutoSize = true;
            this.lblestatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblestatus.Location = new System.Drawing.Point(103, 275);
            this.lblestatus.Name = "lblestatus";
            this.lblestatus.Size = new System.Drawing.Size(58, 15);
            this.lblestatus.TabIndex = 77;
            this.lblestatus.Text = "Estátus:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(94, 225);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 15);
            this.label11.TabIndex = 81;
            this.label11.Text = "Teléfono:";
            // 
            // txt8
            // 
            this.txt8.BackColor = System.Drawing.Color.White;
            this.txt8.Enabled = false;
            this.txt8.Location = new System.Drawing.Point(167, 224);
            this.txt8.MaxLength = 50;
            this.txt8.Name = "txt8";
            this.txt8.ReadOnly = true;
            this.txt8.Size = new System.Drawing.Size(192, 20);
            this.txt8.TabIndex = 79;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(123, 249);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 15);
            this.label1.TabIndex = 83;
            this.label1.Text = "RFC:";
            // 
            // txt9
            // 
            this.txt9.BackColor = System.Drawing.Color.White;
            this.txt9.Enabled = false;
            this.txt9.Location = new System.Drawing.Point(167, 248);
            this.txt9.MaxLength = 50;
            this.txt9.Name = "txt9";
            this.txt9.ReadOnly = true;
            this.txt9.Size = new System.Drawing.Size(192, 20);
            this.txt9.TabIndex = 82;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(61, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(242, 16);
            this.label9.TabIndex = 88;
            this.label9.Text = "INFORMACION DEL PROSPECTO";
            // 
            // cmbestatus
            // 
            this.cmbestatus.FormattingEnabled = true;
            this.cmbestatus.Items.AddRange(new object[] {
            "Aprobado",
            "Rechazado"});
            this.cmbestatus.Location = new System.Drawing.Point(167, 274);
            this.cmbestatus.Name = "cmbestatus";
            this.cmbestatus.Size = new System.Drawing.Size(192, 21);
            this.cmbestatus.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightGreen;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button2.Location = new System.Drawing.Point(280, 370);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(78, 34);
            this.button2.TabIndex = 91;
            this.button2.Text = "Evaluar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtidd
            // 
            this.txtidd.Enabled = false;
            this.txtidd.Location = new System.Drawing.Point(226, 301);
            this.txtidd.Name = "txtidd";
            this.txtidd.ReadOnly = true;
            this.txtidd.Size = new System.Drawing.Size(57, 20);
            this.txtidd.TabIndex = 92;
            this.txtidd.Visible = false;
            // 
            // Evaluacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(371, 415);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.cmbestatus);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt9);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txt8);
            this.Controls.Add(this.lblestatus);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txt7);
            this.Controls.Add(this.txt6);
            this.Controls.Add(this.txt5);
            this.Controls.Add(this.txt4);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblobserv);
            this.Controls.Add(this.btnvolver);
            this.Controls.Add(this.txt10);
            this.Controls.Add(this.txtidd);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Evaluacion";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Evaluacion";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnvolver;
        public System.Windows.Forms.TextBox txt10;
        public System.Windows.Forms.Label lblobserv;
        public System.Windows.Forms.TextBox txt1;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.TextBox txt7;
        public System.Windows.Forms.TextBox txt6;
        public System.Windows.Forms.TextBox txt5;
        public System.Windows.Forms.TextBox txt4;
        public System.Windows.Forms.TextBox txt3;
        public System.Windows.Forms.TextBox txt2;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label lblestatus;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.TextBox txt8;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox txt9;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.ComboBox cmbestatus;
        private System.Windows.Forms.Button button2;
        public System.Windows.Forms.TextBox txtidd;
    }
}