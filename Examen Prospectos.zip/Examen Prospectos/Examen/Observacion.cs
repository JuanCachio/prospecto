﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Examen
{
    public partial class Observacion : Form
    {
        public Observacion()
        {
            InitializeComponent();
        }
        SqlConnection conex = new SqlConnection("SERVER=DESKTOP-2A1QJAA;DATABASE=bdexamen;integrated security=true");
        private void Observacion_Load(object sender, EventArgs e)
        {
            Conexion.Conectar();
            string act = "SELECT OBSERVACIONES = @ob FROM prospectos WHERE id = @id";
            SqlCommand cmd3 = new SqlCommand(act, Conexion.Conectar());
            cmd3.Parameters.AddWithValue("@id", txtiddd.Text);
            cmd3.Parameters.AddWithValue("@ob", txtobserva.Text);
            cmd3.ExecuteNonQuery();
        }

        private void Observacion_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            Listado_de_Prospectos lp = new Listado_de_Prospectos();
            lp.Show();
        }
    }
}
