﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace Examen
{
    public partial class Captura : Form
    {
        public Captura()
        {
            InitializeComponent();
        }

        private void btnguardar_Click(object sender, EventArgs e)
        {
            if (txtarchivo.Text == "")
            {
                MessageBoxButtons bot = MessageBoxButtons.OK;
                DialogResult dr = MessageBox.Show("Porfavor, ingrese su documento", "Advertencia", bot, MessageBoxIcon.Warning);
            }
            else {
             byte[] file = null;
            Stream myStream = openFileDialog1.OpenFile();
            using (MemoryStream ms = new MemoryStream())
            {
                myStream.CopyTo(ms);
                file = ms.ToArray();
            }
                using (Model.bdexamenEntities2 db = new Model.bdexamenEntities2())
                {
                    Model.prospectos oProspects = new Model.prospectos();
                    oProspects.NOMBRE = txtnompros.Text.Trim();
                    oProspects.APELLIDO = txtprimerap.Text.Trim();
                    oProspects.SEGUNDOAPELLIDO = txtsegundoap.Text.Trim();
                    oProspects.CALLE = txtcalle.Text.Trim();
                    oProspects.NUMERO = txtnumero.Text.Trim();
                    oProspects.COLONIA = txtcolonia.Text.Trim();
                    oProspects.CODIGOPOSTAL = txtcp.Text.Trim();
                    oProspects.TELEFONO = txttelefono.Text.Trim();
                    oProspects.RFC = txtrfc.Text.Trim();
                    oProspects.doc = file;
                    oProspects.nombrereal = openFileDialog1.SafeFileName;
                    oProspects.ESTATUS = "ENVIADO";

                    db.prospectos.Add(oProspects);
                    db.SaveChanges();

                    MessageBox.Show("Los Datos Fueron Agregados");

                    txtnompros.Clear();
                    txtprimerap.Clear();
                    txtsegundoap.Clear();
                    txtcalle.Clear();
                    txtnumero.Clear();
                    txtcolonia.Clear();
                    txtcp.Clear();
                    txttelefono.Clear();
                    txtrfc.Clear();
                    txtnompros.Focus();
                    txtarchivo.Clear();

                }
            }
           
            Refresh();
        }
           private void Refresh()
            {
                using (Model.bdexamenEntities2 db = new Model.bdexamenEntities2())
                {
                Listado_de_Prospectos lp = new Listado_de_Prospectos();
                    var lst = from d in db.prospectos
                              select new { d.NOMBRE };
                lp.dtlistado.DataSource = lst.ToList();
                }

            }

        private void btnvolver_Click(object sender, EventArgs e)
        {
            if(txtnompros.Text == "")
            {
                Form1 f1 = new Form1();
                f1.Show();
                this.Hide();
            }
            else
            {
                MessageBoxButtons bot = MessageBoxButtons.OKCancel;
                DialogResult dr = MessageBox.Show("¿Seguro(a) que quiere salir? Sus datos serán removidos", "Advertencia", bot, MessageBoxIcon.Warning);

                if (dr == DialogResult.OK)
                {
                    
                    Form f1 = new Form1();
                    f1.Show();
                    this.Hide();
                }
            }
        }

        private void btnadjuntar_Click_1(object sender, EventArgs e)
        {
            openFileDialog1.InitialDirectory = "C:\\";
            openFileDialog1.Filter = "Todos los Archivos (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtarchivo.Text = openFileDialog1.FileName;
            }
        }
    }
}
