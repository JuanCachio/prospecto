﻿namespace Examen
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BTNCAPTURA = new System.Windows.Forms.Button();
            this.btnlistado = new System.Windows.Forms.Button();
            this.lbl1 = new System.Windows.Forms.Label();
            this.btnsalir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BTNCAPTURA
            // 
            this.BTNCAPTURA.BackColor = System.Drawing.Color.LimeGreen;
            this.BTNCAPTURA.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTNCAPTURA.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BTNCAPTURA.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNCAPTURA.ForeColor = System.Drawing.SystemColors.ControlText;
            this.BTNCAPTURA.Location = new System.Drawing.Point(12, 85);
            this.BTNCAPTURA.Name = "BTNCAPTURA";
            this.BTNCAPTURA.Size = new System.Drawing.Size(255, 87);
            this.BTNCAPTURA.TabIndex = 0;
            this.BTNCAPTURA.Text = "CAPTURAR";
            this.BTNCAPTURA.UseVisualStyleBackColor = false;
            this.BTNCAPTURA.Click += new System.EventHandler(this.BTNCAPTURA_Click);
            // 
            // btnlistado
            // 
            this.btnlistado.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnlistado.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnlistado.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnlistado.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlistado.Location = new System.Drawing.Point(276, 85);
            this.btnlistado.Name = "btnlistado";
            this.btnlistado.Size = new System.Drawing.Size(255, 87);
            this.btnlistado.TabIndex = 1;
            this.btnlistado.Text = "LISTADO";
            this.btnlistado.UseVisualStyleBackColor = false;
            this.btnlistado.Click += new System.EventHandler(this.btnlistado_Click);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(86, 9);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(364, 73);
            this.lbl1.TabIndex = 3;
            this.lbl1.Text = "Prospectos";
            this.lbl1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnsalir
            // 
            this.btnsalir.BackColor = System.Drawing.Color.IndianRed;
            this.btnsalir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnsalir.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnsalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsalir.Location = new System.Drawing.Point(436, 187);
            this.btnsalir.Name = "btnsalir";
            this.btnsalir.Size = new System.Drawing.Size(95, 25);
            this.btnsalir.TabIndex = 4;
            this.btnsalir.Text = "SALIR";
            this.btnsalir.UseVisualStyleBackColor = false;
            this.btnsalir.Click += new System.EventHandler(this.btnsalir_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(543, 221);
            this.Controls.Add(this.btnsalir);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.btnlistado);
            this.Controls.Add(this.BTNCAPTURA);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Inicio";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BTNCAPTURA;
        private System.Windows.Forms.Button btnlistado;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Button btnsalir;
    }
}

