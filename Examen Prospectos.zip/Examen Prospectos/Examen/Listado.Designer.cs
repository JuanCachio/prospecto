﻿namespace Examen
{
    partial class Listado_de_Prospectos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtlistado = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.btnvolver = new System.Windows.Forms.Button();
            this.btnabrir = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtlistado)).BeginInit();
            this.SuspendLayout();
            // 
            // dtlistado
            // 
            this.dtlistado.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.dtlistado.AllowUserToAddRows = false;
            this.dtlistado.AllowUserToDeleteRows = false;
            this.dtlistado.AllowUserToResizeColumns = false;
            this.dtlistado.AllowUserToResizeRows = false;
            this.dtlistado.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtlistado.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dtlistado.ColumnHeadersHeight = 25;
            this.dtlistado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dtlistado.Location = new System.Drawing.Point(0, 0);
            this.dtlistado.MultiSelect = false;
            this.dtlistado.Name = "dtlistado";
            this.dtlistado.ReadOnly = true;
            this.dtlistado.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dtlistado.RowHeadersVisible = false;
            this.dtlistado.RowHeadersWidth = 520;
            this.dtlistado.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dtlistado.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtlistado.Size = new System.Drawing.Size(397, 241);
            this.dtlistado.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.PaleGreen;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(403, 162);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(109, 38);
            this.button1.TabIndex = 1;
            this.button1.Text = "Evaluar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnvolver
            // 
            this.btnvolver.BackColor = System.Drawing.Color.LightCoral;
            this.btnvolver.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnvolver.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnvolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvolver.Location = new System.Drawing.Point(403, 206);
            this.btnvolver.Name = "btnvolver";
            this.btnvolver.Size = new System.Drawing.Size(109, 35);
            this.btnvolver.TabIndex = 2;
            this.btnvolver.Text = "Volver";
            this.btnvolver.UseVisualStyleBackColor = false;
            this.btnvolver.Click += new System.EventHandler(this.btnvolver_Click_1);
            // 
            // btnabrir
            // 
            this.btnabrir.BackColor = System.Drawing.Color.DarkGray;
            this.btnabrir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnabrir.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnabrir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnabrir.Location = new System.Drawing.Point(403, 9);
            this.btnabrir.Name = "btnabrir";
            this.btnabrir.Size = new System.Drawing.Size(109, 40);
            this.btnabrir.TabIndex = 4;
            this.btnabrir.Text = "Ver documento";
            this.btnabrir.UseVisualStyleBackColor = false;
            this.btnabrir.Click += new System.EventHandler(this.btnabrir_Click_1);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.PowderBlue;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(403, 58);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(109, 41);
            this.button3.TabIndex = 6;
            this.button3.Text = "Ver observacion";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Listado_de_Prospectos
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(519, 245);
            this.Controls.Add(this.dtlistado);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnabrir);
            this.Controls.Add(this.btnvolver);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Listado_de_Prospectos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Listado_de_Prospectos";
            this.Load += new System.EventHandler(this.Listado_de_Prospectos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtlistado)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnvolver;
        private System.Windows.Forms.Button btnabrir;
        public System.Windows.Forms.DataGridView dtlistado;
        private System.Windows.Forms.Button button3;
    }
}