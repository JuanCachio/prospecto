﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Examen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BTNCAPTURA_Click(object sender, EventArgs e)
        {
            Captura c = new Captura();
            c.Show();
            this.Hide();
        }

        private void btnlistado_Click(object sender, EventArgs e)
        {

            Listado_de_Prospectos lp = new Listado_de_Prospectos();
            lp.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Evaluacion ev = new Evaluacion();
            ev.Show();
        }
        private void btnsalir_Click(object sender, EventArgs e)
        {
            MessageBoxButtons bot = MessageBoxButtons.OKCancel;
            DialogResult dr = MessageBox.Show("¿Seguro(a) que quiere salir?", "Advertencia", bot, MessageBoxIcon.Warning);

            if (dr == DialogResult.OK)
            {
                Application.Exit();
            }
        }
    }
}
