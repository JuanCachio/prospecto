﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;

namespace Examen
{
    public partial class Listado_de_Prospectos : Form
    {
        public Listado_de_Prospectos()
        {
            InitializeComponent();

        }
        SqlConnection conex = new SqlConnection("SERVER=DESKTOP-2A1QJAA;DATABASE=bdexamen;integrated security=true");
        Captura c = new Captura();

        private void Listado_de_Prospectos_Load(object sender, EventArgs e)
        {
            string consulta = "select NOMBRE, APELLIDO, SEGUNDOAPELLIDO, ESTATUS, id, CALLE, NUMERO, COLONIA, CODIGOPOSTAL, TELEFONO, RFC, OBSERVACIONES, nombrereal FROM prospectos";
            SqlDataAdapter adapt = new SqlDataAdapter(consulta, conex);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            dtlistado.DataSource = dt;
            Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Evaluacion ev = new Evaluacion();
            
            ev.txtidd.Text = dtlistado.CurrentRow.Cells["id"].Value.ToString();
            ev.txt1.Text = dtlistado.CurrentRow.Cells["NOMBRE"].Value.ToString();
            ev.txt2.Text = dtlistado.CurrentRow.Cells["APELLIDO"].Value.ToString();
            ev.txt3.Text = dtlistado.CurrentRow.Cells["SEGUNDOAPELLIDO"].Value.ToString();
            ev.txt4.Text = dtlistado.CurrentRow.Cells["CALLE"].Value.ToString();
            ev.txt5.Text = dtlistado.CurrentRow.Cells["NUMERO"].Value.ToString();
            ev.txt6.Text = dtlistado.CurrentRow.Cells["COLONIA"].Value.ToString();
            ev.txt7.Text = dtlistado.CurrentRow.Cells["CODIGOPOSTAL"].Value.ToString();
            ev.txt8.Text = dtlistado.CurrentRow.Cells["TELEFONO"].Value.ToString();
            ev.txt9.Text = dtlistado.CurrentRow.Cells["RFC"].Value.ToString();
            ev.cmbestatus.Text = dtlistado.CurrentRow.Cells["ESTATUS"].Value.ToString();
            ev.txt10.Text = dtlistado.CurrentRow.Cells["OBSERVACIONES"].Value.ToString();
            ev.cmbestatus.Focus();
            ev.Show();

        }
        private void btnvolver_Click_1(object sender, EventArgs e)
        {
            
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }
        private void btnabrir_Click_1(object sender, EventArgs e)
        {
            if (dtlistado.Rows.Count > 0)
            {

                int id = int.Parse(dtlistado.Rows[dtlistado.CurrentRow.Index].Cells["id"].Value.ToString());

                using (Model.bdexamenEntities2 db = new Model.bdexamenEntities2()) 
                {
                    var oProspectos = db.prospectos.Find(id);

                    string path = AppDomain.CurrentDomain.BaseDirectory;
                    string folder = path + "/temp/";
                    string fullFilePath = folder + oProspectos.nombrereal;

                    if (!Directory.Exists(folder))
                        Directory.CreateDirectory(folder);

                    if (File.Exists(fullFilePath))
                        File.Delete(fullFilePath);

                    File.WriteAllBytes(fullFilePath, oProspectos.doc);

                    Process.Start(fullFilePath);
                }
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Observacion ob = new Observacion();
            ob.txtiddd.Text = dtlistado.CurrentRow.Cells["id"].Value.ToString();
            ob.txtobserva.Text = dtlistado.CurrentRow.Cells["OBSERVACIONES"].Value.ToString();
            ob.Show();
        }
    }
}
